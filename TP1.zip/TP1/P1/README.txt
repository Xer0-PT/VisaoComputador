P1
---

IMAGENS:
- Ficheiro: img1.ppm
- Resolu��o: 312x312
- Depth: 8bpp
- Espa�o de Cor: Tons de cinzento
- Fonte: RM

DESCRI��O:
A imagem (img1.ppm) apresenta uma imagem de uma resson�ncia magn�tica (RM) realizada � cabe�a de um paciente.


OBJECTIVOS:
Este trabalho tem como objectivo desenvolver um programa em linguagem C, que processe  a imagem fornecida, de modo a calcular a �rea do c�rebro (a aplica��o dever� excluir os p�xeis do cr�nio), per�metro e respetivo centro de massa. A aplica��o dever�, ainda, produzir uma imagem semelhante � de entrada, mas que apresente apenas o c�rebro, isto �, removendo a estrutura do cr�nio.